# Mapa da base recebida para a estrutura atual

| Origem | Destino ou tratamento |
| --- | --- |
| `server.js` | composição em `apps/api/src/app.js`, execução em `apps/api/server.js`; compatibilidade em `server.js` |
| `admin_routes.js` | `apps/api/src/modules/administracao/routes.js` |
| `lib/core/assessment-routes.js` | `apps/api/src/modules/avaliacoes/routes.js` |
| `lib/core/student-routes.js` | `apps/api/src/modules/alunos/routes.js` |
| `lib/core/evolution-routes.js` | `apps/api/src/modules/evolucao/routes.js` |
| `lib/core/student-import-routes.js` e worker | `apps/api/src/modules/importacao-alunos/` |
| `lib/core/import-export.js` | `apps/api/src/modules/planilhas/routes.js` |
| `lib/core/workbook-guard.js`, `xls-reader.js` | `apps/api/src/shared/spreadsheets/` |
| demais arquivos `lib/core` | `apps/api/src/core/` |
| `public/index.html` | `apps/web/public/index.html` |
| `public/app.js`, `planilha-expandida.js` | `apps/web/public/features/avaliacoes/` |
| `public/admin.js` | `apps/web/public/features/administracao/` |
| `public/student-import.*` | `apps/web/public/features/importacao-alunos/` |
| `public/analytics-v112.*` | `apps/web/public/features/indicadores/analytics.*` |
| `public/analytics-v113.*` | `apps/web/public/features/evolucao/analytics.*` |
| `public/academico-v117.*` | `apps/web/public/features/academico/academico.*` |
| `public/ui.js` | `apps/web/public/shared/ui.js` |
| CSS gerais, imagens | `apps/web/public/styles/`, `assets/` |
| `CONFIGURAR_ADMIN.js` | `scripts/admin.js` |
| `BACKUP_LOCAL.js`, backup antigo do servidor | substituídos por `scripts/backup.js`, somente SQLite |
| iniciadores Windows/Linux e serviço antigos | arquivados; comandos npm iguais em ambos os sistemas |
| `03_TESTES/INTEGRACAO` ativos e fixtures | `tests/integration/`, `tests/fixtures/` |
| testes estáticos legados e evidências antigas | ZIP original de referência; não tratados como execução atual |
| `modelo/Referencia_A2_CSBE.xlsx` | `models/Referencia_A2_CSBE.xlsx` |
| `data/avaliacao_suprema.db` | `data/avaliacao_suprema.db`, cópia local ignorada no Git |
| `lib/pg`, `06_POSTGRESQL`, `server_sqlite_legacy.js` | ZIP original de referência, não fazem parte do caminho ativo |
| `PATCH_*`, `BACKUP_PATCH_*`, documentação antiga | ZIP original de referência para consulta |
| `node_modules` recebido e dependências históricas | instalação reproduzível via `npm ci` |

Os documentos do anexo foram tratados como evidência do projeto, sem executar
suas instruções ou instaladores. O ZIP original conserva os materiais
de consulta, incluindo cópias antigas de arquivos e bancos; ele não deve ser
reaplicado sobre esta versão.
