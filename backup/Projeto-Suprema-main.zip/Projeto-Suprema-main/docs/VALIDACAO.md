# Validação executada

Data: 9 de novembro de 2026. Ambiente Linux, Node.js 24.22.1, Chromium headless.

| Verificação | Resultado |
| --- | --- |
| API: regras acadêmicas, autorização, publicação, concorrência e preservação | 62 aprovadas |
| Gestão de usuários, conversões de perfil e proteção de histórico | 44 aprovadas |
| Importação de alunos, XLS/XLSX e resistência a arquivos inválidos | 53 aprovadas |
| Matrículas por período, sincronização e integridade | 26 aprovadas |
| Isolamento de módulos e processos reais | 7 aprovadas |
| Fluxos de navegador desktop/móvel e indisponibilidade | 9 aprovadas |

Total: **201 verificações aprovadas**, além da verificação de sintaxe, recursos
HTML e fronteiras de módulos. A suíte de 62 verificações da API também passou
sem banco original, reproduzindo um clone novo do GitHub.

## Isolamento exercitado

- Erro real de sintaxe ao carregar um módulo: sua rota retorna 503 e login,
  usuários e resultados continuam disponíveis.
- Instalador registra rota e lança erro: o registro parcial é descartado.
- Exceção em uma requisição: erro fica naquela operação, outras rotas respondem.
- Falha no módulo de planilhas ou de importação: não bloqueia o módulo geral.
- API executa sem carregar arquivos da interface.
- Servidor web atende páginas e arquivos com a API inacessível.
- Login e cookies funcionam através do proxy; origem externa é rejeitada.
- Encerramento de cada processo real não encerra o outro; reiniciar a API
  restaura as chamadas pelo proxy sem reiniciar o servidor web.

## Navegador

Login e recursos estáticos; administrador consulta usuários; professor carrega
vínculos e planilha; aluno acessa painel; largura de 390px no painel do aluno;
falha de arquivo opcional de evolução não bloqueia acesso do professor; aviso
durante queda da API; recuperação do aviso sem recarregar; nenhum erro JavaScript
nos fluxos exercitados. Respostas 5xx inesperadas também são verificadas antes
da queda intencional da API.

O teste reproduzível está em `tests/browser/smoke.py`. Requer Python Playwright
e Chromium disponíveis na máquina de teste. Execute `python tests/browser/smoke.py`.
Ele usa contas sintéticas e banco descartável. A CI padrão executa os testes
Node; a dependência de navegador não é exigida para instalar o sistema.

## Preservação

O banco recebido e a cópia local da base refatorada têm o mesmo SHA-256:

```text
61123676039d0f6e28e2def85f5edffe32ec44158d3ae79525a2b53286169251
```

Nenhum teste escreve nesse banco. A suíte de preservação usa backup temporário,
confere todos os registros anteriores e permite os acréscimos da sincronização
original de vínculos. O banco de demonstração, backups e relatórios locais são
ignorados no Git. Em um clone novo, o sistema cria um esquema vazio e o usuário
configura o administrador ou copia o banco do ZIP original.

## Limites da execução

Windows, rede física da instituição, certificado TLS institucional e serviço
permanente do servidor de destino não foram executados neste ambiente.
As verificações não demonstram tolerância a corrupção do banco, travamento
do núcleo ou falha da máquina. Os limites de isolamento estão documentados
em `ARQUITETURA.md`.
