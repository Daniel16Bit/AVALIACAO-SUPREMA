# Arquitetura e isolamento de falhas

```mermaid
flowchart LR
  Browser[Navegador] --> Web[Interface web :3002]
  Web -->|/api, proxy HTTP| API[API :3003]
  API --> Auth[Núcleo de segurança]
  Auth --> Modules[Módulos de rotas]
  Modules --> DB[(SQLite local)]
```

## Interface e API

O servidor `apps/web/server.js` usa apenas módulos nativos de Node.js. Ele serve
exclusivamente `apps/web/public`, com validação de caminhos e sem expor o banco.
Também encaminha `/api` ao destino configurado. O navegador usa sempre a mesma
origem; o proxy mantém o Host público, cookies de sessão e respostas de erro.
Requisições de escrita com Origin diferente são rejeitadas na interface e API.
Cabeçalhos hop-by-hop e encaminhamentos fornecidos pelo cliente são removidos.
O proxy encerra uma operação após 30 segundos sem resposta completa. Um timeout
não permite concluir se o servidor confirmou uma escrita antes da desconexão:
atualize o estado antes de repetir uma operação. Não há repetição automática.

Os arquivos de interface foram separados por funcionalidade mantendo a ordem
de scripts e estilos. O comportamento visual e as fórmulas existentes foram
mantidos. O cliente HTTP comum trata respostas e falhas de conexão. Um aviso
independente consulta a saúde a cada 15 segundos, sem recarregar a página.

## Módulos da API

| Módulo | Rotas sob sua responsabilidade |
| --- | --- |
| importacao-alunos | `/api/admin/student-import/*` |
| planilhas | `/api/assessment/:id/import`, `/import/confirm`, `/export` |
| administracao | demais `/api/admin/*` |
| avaliacoes | demais `/api/assessment/*` e `/api/assessments` |
| evolucao | `/api/evolution` |
| alunos | `/api/student/*` |

O manifesto em `apps/api/src/modules/index.js` contém carregadores adiados.
Cada instalador recebe um Router isolado e o mesmo contexto de banco e segurança.
Só depois do registro completo o Router é publicado. Se `require` ou instalação
falhar, o Router é descartado e uma resposta 503 fica restrita às rotas daquele
módulo. Os módulos mais específicos são registrados primeiro para uma falha na
importação não impedir os cadastros ou as avaliações.

O indicador por módulo em `/api/health` descreve o **carregamento na inicialização**;
não é uma monitoração permanente de todas as operações. Erros nas requisições
seguem para o tratador de erro central. Não se descarrega um módulo nem se abre
permissão de acesso como recuperação. Autenticação e banco são essenciais: se
falharem ao iniciar, a API não fica disponível. O servidor web permanece separado.

## Limites

O isolamento de processos protege a disponibilidade dos servidores web e API.
O isolamento de Routers protege contra falhas de carregamento e erros tratáveis
de requisição em funcionalidades. Os módulos não são serviços independentes:
compartilham memória, banco e event loop. Um loop infinito, `process.exit`, falta
de memória ou falha nativa pode derrubar a API inteira. A interface permanece
acessível, mas não consulta nem salva dados sem uma API funcional.

Componentes comuns da interface (`shared`, HTML base e a aplicação principal)
também são dependências compartilhadas. A separação em pastas não elimina essa
dependência. Alterações nesse núcleo exigem os testes integrados.

## Banco e compatibilidade

`data/avaliacao_suprema.db` continua no mesmo local. `SUPREMA_DATA_DIR` permite
usar outro diretório. A cópia local usada na validação mantém os bytes do arquivo recebido; o banco
não é versionado no GitHub.
Testes usam diretórios temporários, e a validação da migração usa uma cópia do
banco. A inicialização original continua fazendo migrações aditivas e sincroniza
vínculos, podendo criar A3 e linhas de rascunho ausentes. Notas, publicações e
senhas anteriores são verificadas. Reinícios não recriam contas padrão.

`server.js` continua exportando `createApplication` e `start` da API para clientes
que importavam esse arquivo. `node server.js` e `npm start` iniciam o conjunto.
O `start` exportado inicia somente a API, agora na porta 3003 por padrão.
`PORT` configura o acesso web; `API_PORT` configura a API. Os scripts operacionais
antigos foram arquivados porque vários apontavam para outro banco ou contrato.
