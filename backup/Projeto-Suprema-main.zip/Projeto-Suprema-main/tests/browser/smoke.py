"""Browser smoke test. Requires Python Playwright and Chromium on the test host.

Uses synthetic accounts and a disposable database; never opens data/.
Run from the project root: python tests/browser/smoke.py
"""
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import tempfile
import time
import urllib.error
import urllib.request

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[2]
REPORTS = ROOT / "tests/reports"
REPORTS.mkdir(exist_ok=True)


def free_port():
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def wait_for(url):
    for _ in range(100):
        try:
            with urllib.request.urlopen(url, timeout=1) as response:
                if response.status == 200:
                    return
        except (OSError, urllib.error.URLError):
            time.sleep(0.1)
    raise RuntimeError("Service unavailable: " + url)


def request(base, url, data=None, cookie=None):
    headers = {"Content-Type": "application/json"}
    if cookie:
        headers["Cookie"] = cookie
    req = urllib.request.Request(base + url, data=json.dumps(data).encode() if data is not None else None, headers=headers)
    with urllib.request.urlopen(req) as response:
        return json.load(response), response.headers.get("Set-Cookie", "").split(";")[0]


def run():
    with tempfile.TemporaryDirectory(prefix="suprema-browser-") as temp:
        api_port, web_port = free_port(), free_port()
        api_url, web_url = f"http://127.0.0.1:{api_port}", f"http://127.0.0.1:{web_port}"
        env = {**os.environ, "API_PORT": str(api_port), "PORT": str(web_port), "API_URL": api_url, "SUPREMA_DATA_DIR": temp}
        # Synthetic local setup via the same admin configurator as the CLI.
        subprocess.run(["node", "-e", "const s=require('./apps/api/src/core/database').openDatabase();try{require('./scripts/admin').configureAdmin(s.db,{name:'Admin Browser',email:'admin@browser.invalid',password:'Browser-Admin-123!'});}finally{s.db.close();}"], cwd=ROOT, env=env, check=True, capture_output=True)
        with open(Path(temp) / "process.log", "w") as log:
            api = subprocess.Popen(["node", "apps/api/server.js"], cwd=ROOT, env=env, stdout=log, stderr=log)
            web = subprocess.Popen(["node", "apps/web/server.js"], cwd=ROOT, env=env, stdout=log, stderr=log)
            try:
                wait_for(api_url + "/api/ready")
                wait_for(web_url + "/health")
                _, cookie = request(web_url, "/api/login", {"login": "admin@browser.invalid", "password": "Browser-Admin-123!"})

                def create(route, data):
                    return request(web_url, "/api/admin/" + route, data, cookie)[0]

                teacher = create("users", {"name": "Professor Browser", "email": "prof@browser.invalid", "matricula": "PROF-BROWSER", "password": "Browser-Prof-123!", "role": "PROFESSOR"})
                student = create("users", {"name": "Aluno Browser", "email": "aluno@browser.invalid", "matricula": "ALUNO-BROWSER", "password": "Browser-Aluno-123!", "role": "ALUNO", "period": "3"})
                course = create("courses", {"name": "Curso Browser"})
                discipline = create("disciplines", {"course_id": course["id"], "name": "Disciplina Browser", "period": "3"})
                create("assignments", {"discipline_id": discipline["id"], "professor_id": teacher["id"], "year": 2026, "semester": "2", "class_name": ""})
                create("enrollments", {"discipline_id": discipline["id"], "student_id": student["student_id"], "year": 2026, "semester": "2", "class_name": ""})
                checks, errors, server_errors = [], [], []
                with sync_playwright() as pw:
                    chromium = shutil.which("chromium") or shutil.which("chromium-browser")
                    browser = pw.chromium.launch(executable_path=chromium, headless=True, args=["--no-sandbox"])
                    context = browser.new_context(viewport={"width": 1440, "height": 1000})
                    page = context.new_page()
                    page.on("pageerror", lambda error: errors.append(str(error)))
                    page.on("response", lambda response: server_errors.append(response.url) if response.status >= 500 else None)

                    def login(user, password, screen):
                        context.clear_cookies()
                        page.goto(web_url)
                        page.locator("#loginInput").fill(user)
                        page.locator("#passwordInput").fill(password)
                        page.locator("#loginForm button[type=submit]").click()
                        page.locator(screen).wait_for(state="visible")

                    page.goto(web_url)
                    page.locator("#loginForm").wait_for(state="visible")
                    checks.append("Login e recursos estaticos carregam")
                    login("admin@browser.invalid", "Browser-Admin-123!", "#adminScreen")
                    page.get_by_role("heading", name="Visão geral", exact=True).wait_for()
                    page.locator("#adminContent .admin-stat").first.wait_for()
                    page.locator('[data-admin-view="users"]').click()
                    page.get_by_text("Professor Browser", exact=True).wait_for()
                    page.screenshot(path=str(REPORTS / "browser-admin.png"), full_page=True)
                    checks.append("Administrador consulta usuarios atraves do proxy")
                    login("prof@browser.invalid", "Browser-Prof-123!", "#appScreen")
                    page.locator("#scoresTable tbody tr").first.wait_for()
                    assert page.locator("#scoresTable").inner_text().find("Aluno Browser") >= 0
                    page.screenshot(path=str(REPORTS / "browser-professor.png"), full_page=True)
                    checks.append("Professor carrega vinculos e planilha")
                    login("aluno@browser.invalid", "Browser-Aluno-123!", "#studentScreen")
                    page.locator("#studentResultBody").wait_for(state="visible")
                    checks.append("Aluno acessa painel sem resultados ficticios")
                    page.set_viewport_size({"width": 390, "height": 844})
                    page.screenshot(path=str(REPORTS / "browser-aluno-mobile.png"), full_page=True)
                    assert page.evaluate("document.documentElement.scrollWidth <= window.innerWidth")
                    checks.append("Painel do aluno cabe em tela de 390px")
                    # A missing optional frontend enhancement does not stop login.
                    page.route("**/features/evolucao/analytics.js", lambda route: route.abort())
                    login("prof@browser.invalid", "Browser-Prof-123!", "#appScreen")
                    page.locator("#scoresTable tbody tr").first.wait_for()
                    checks.append("Arquivo opcional de evolucao ausente nao impede professor")
                    page.unroute("**/features/evolucao/analytics.js")
                    assert not server_errors, server_errors
                    context.clear_cookies()
                    page.goto(web_url)
                    api.terminate()
                    api.wait(timeout=10)
                    page.reload()
                    page.locator("#serviceStatus").wait_for(state="visible")
                    assert "indisponivel" in page.locator("#serviceStatus").inner_text()
                    page.locator("#loginForm").wait_for(state="visible")
                    checks.append("Interface continua aberta e informa queda da API")
                    page.screenshot(path=str(REPORTS / "browser-api-offline.png"), full_page=True)
                    api = subprocess.Popen(["node", "apps/api/server.js"], cwd=ROOT, env=env, stdout=log, stderr=log)
                    wait_for(api_url + "/api/ready")
                    # The status check runs every 15s, no page reload required.
                    page.locator("#serviceStatus").wait_for(state="hidden", timeout=20000)
                    checks.append("Aviso desaparece apos API se recuperar sem recarregar tela")
                    assert not errors, errors
                    checks.append("Nenhum erro JavaScript nos fluxos testados")
                    browser.close()
                (REPORTS / "browser-smoke.json").write_text(json.dumps({"status": "APROVADO", "checks": checks, "javascript_errors": errors}, indent=2, ensure_ascii=False))
                print(f"{len(checks)} verificacoes de navegador aprovadas")
            finally:
                for process in (api, web):
                    if process.poll() is None:
                        process.terminate()
                        try:
                            process.wait(timeout=10)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait()


if __name__ == "__main__":
    run()
