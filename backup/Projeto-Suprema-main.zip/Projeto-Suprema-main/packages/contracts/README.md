# Contrato entre interface e API

Toda chamada do navegador usa um caminho relativo começando por `/api`.
`API_URL` pertence ao servidor web; não é inserida no JavaScript público.

| Operação | Rota | Observações |
| --- | --- | --- |
| Entrar | `POST /api/login` | JSON `{login,password}`; retorna `{ok,user}` e cookie HttpOnly |
| Sessão | `GET /api/me` | `{id,name,role,studentId}`; 401 sem sessão |
| Sair | `POST /api/logout` | invalida sessão e cookie |
| Saúde | `GET /api/health` | estado da API e carregamento dos módulos |
| Prontidão | `GET /api/ready` | 200 completo, 503 degradado |
| Administração | `/api/admin/*` | perfil ADMIN |
| Avaliações | `/api/assessments`, `/api/assessment/:id/*` | professor vinculado |
| Resultados publicados | `/api/student/*` | aluno titular |
| Evolução | `GET /api/evolution` | ADMIN ou PROFESSOR, conforme autorização |

Erros retornam JSON `{error: string}` com status HTTP. Indisponibilidade adiciona
`code: 'API_UNAVAILABLE'` (proxy) ou `code: 'MODULE_UNAVAILABLE'` e `module` (API).
401 exige autenticação; 403 nega permissão; 409 indica conflito; 423 indica
bloqueio operacional. A interface só confirma operações após resposta de sucesso.
Não há sucesso fictício nem armazenamento offline substituindo o banco.

Gravações de avaliação usam o campo `revision` do estado carregado. Revisão
antiga retorna 409; a interface deve atualizar e pedir conciliação das mudanças.
Rascunho e resultado publicado continuam separados. Publicar exige validação
no servidor. Falha na confirmação não permite inferir sucesso da operação.

Importação de notas mantém `multipart/form-data`; prévia de importação de
alunos mantém `application/octet-stream`. Exportação retorna arquivo binário.
O proxy transmite corpos e respostas em streaming; não converte tudo para JSON.

Para adicionar um módulo, registre suas rotas e o predicado `owns` no manifesto,
priorizando rotas específicas antes de rotas gerais. Adicione teste para a falha
do módulo e mantenha a autenticação nas rotas. Módulos não importam diretamente
outros módulos; regras comuns pertencem ao núcleo ou a `shared`.
