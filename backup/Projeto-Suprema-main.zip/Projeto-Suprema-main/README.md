# Avaliação Suprema

Base reorganizada a partir de `AVALIACAO_SUPREMA_3_PERIODO_DEMO_PRONTO.zip`.
Interface e API executam em processos separados e se comunicam por HTTP.
O sistema ativo usa **SQLite**, preservando as regras e as rotas da base recebida.

## Começar

Instale Node.js **22.16 ou superior** (recomendado: Node.js 24 LTS).
Na pasta do projeto:

```sh
npm ci
npm start
```

Abra **http://localhost:3002**. A API fica em http://127.0.0.1:3003.

No clone do GitHub, o banco começa vazio. Crie o administrador:

```sh
npm run admin
```

O ZIP original enviado contém o banco de demonstração. A refatoração não altera esse arquivo.
Para usar seu banco existente, com os servidores desligados, copie a pasta
`data` ou defina `SUPREMA_DATA_DIR` em `.env`. Não sobreponha bancos em uso.
O sistema mantém a inicialização original: ajustes de esquema e criação das
avaliações ausentes de vínculos ativos acontecem na primeira abertura. Notas
e publicações existentes são preservadas; a inicialização não redefine senhas.

## Duas pessoas trabalhando

| Área | Pasta principal | Comando independente |
| --- | --- | --- |
| Pessoa 1: telas, estilos, comportamento da interface | `apps/web/` | `npm run start:web` |
| Pessoa 2: regras, rotas, autorização, dados | `apps/api/` | `npm run start:api` |
| Acordo entre as duas partes | `packages/contracts/` | revisar alterações em conjunto |

A interface pode iniciar sem instalar as dependências da API:
`node apps/web/server.js`. A API pode iniciar sem carregar nenhum arquivo de tela.
Para desenvolver a interface com uma API em outra máquina, configure `API_URL`
em `.env`. Para acessar pela rede local, configure `HOST=0.0.0.0` e use o IP do
computador na porta 3002. A API permanece local por padrão.

Use uma branch por tarefa, faça pull requests para `main` e combine mudanças nas
rotas antes de alterar o contrato. Cada pessoa usa seu clone e seu banco local.
Consulte [o fluxo de colaboração](docs/COLABORACAO.md).

## Organização

```text
apps/
  web/                  interface, servidor estático e proxy /api
    public/
      features/         avaliações, administração, importação, indicadores…
      shared/           cliente HTTP, estado de conexão e componentes comuns
      styles/           estilos gerais
      assets/           imagens
  api/
    src/
      core/             banco, segurança e regras compartilhadas
      modules/          módulos de rotas com carregamento independente
      shared/           validação e leitura de planilhas
packages/
  contracts/            rotas e regras de integração
  http/                 cabeçalhos e validação de origem
scripts/                inicialização, administrador, backup e verificações
tests/                  isolamento, regressão, fixtures e relatórios locais
docs/                   arquitetura, colaboração, migração e análise
models/                 planilha modelo original
data/                   banco local; não entra no Git
archive/                orientação sobre o histórico separado
```

O [mapa de migração](docs/MAPA_DE_PASTAS.md) explica onde cada arquivo foi colocado.
Os casos de uso, diagramas de classes, imagens e fontes PlantUML estão na
[documentação de modelagem UML](docs/modelagem/README.md).

## Quando um lado falhar

- **API desligada:** interface e arquivos continuam acessíveis; operações de
  dados retornam 503 e a tela avisa sobre a indisponibilidade. Não há salvamento
  offline ou confirmação falsa. Rascunhos em memória podem permanecer na tela;
  valide o estado no servidor após a reconexão.
- **Interface desligada ou um arquivo visual quebrado:** a API continua ativa.
- **Erro ao carregar um módulo da API:** somente suas rotas retornam 503. O
  registro parcial de rotas é descartado; os outros módulos são carregados.
- **Erro comum em uma requisição:** retorna erro naquela operação sem encerrar
  o servidor. Reinicie o processo da API depois de corrigir código de módulo.
- **Falha no banco, núcleo de segurança, processo da API ou máquina:** afeta os
  serviços que dependem desse recurso. Os módulos compartilham banco e processo;
  não há garantia contra travamento, falta de memória ou corrupção do banco.

`npm start` mantém o outro processo ativo quando um encerra. Reinicie somente
o serviço corrigido em outro terminal com seu comando independente. Em produção,
use um gerenciador de serviços com duas unidades para reinício individual.

## Comandos

```sh
npm run check          # sintaxe, recursos HTML e fronteiras entre módulos
npm test               # isolamento e regressões de API
npm run backup         # backup SQLite consistente, incluindo transações confirmadas
```

`/health` verifica a interface; `/api/health` indica o estado da API e dos módulos;
`/api/ready` retorna 503 se algum módulo não carregou.
Copie `.env.example` para `.env` se precisar mudar portas, caminhos ou TLS.
Cada serviço carrega `.env` com os comandos npm. TLS termina na interface web;
a API local recebe cookies seguros quando TLS está configurado. Com proxy HTTPS
externo, configure `SUPREMA_SECURE_COOKIE=1` na API.

Banco, backups, senhas locais, dependências e histórico não são versionados.
O ZIP original permanece como histórico para consulta. Seus instaladores e
documentos antigos não definem o fluxo desta versão.
