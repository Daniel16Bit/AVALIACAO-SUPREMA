'use strict';
const fs = require('node:fs/promises');
const path = require('node:path');
const {DatabaseSync, backup} = require('node:sqlite');
const ROOT = path.resolve(__dirname, '..');

async function createBackup(source = path.join(process.env.SUPREMA_DATA_DIR || path.join(ROOT, 'data'), 'avaliacao_suprema.db'), destination = process.env.SUPREMA_BACKUP_DIR || path.join(ROOT, 'backups')) {
  await fs.access(source);
  await fs.mkdir(destination, {recursive: true});
  let folder;
  for (let n = 1; ; n++) {
    folder = path.join(destination, 'BACKUP_' + String(n).padStart(3, '0'));
    try {await fs.mkdir(folder); break;} catch (err) {if (err.code !== 'EEXIST') throw err;}
  }
  const dest = path.join(folder, 'avaliacao_suprema.db');
  const db = new DatabaseSync(source, {readOnly: true});
  try {
    await backup(db, dest);
    const check = new DatabaseSync(dest, {readOnly: true});
    try {
      if (check.prepare('PRAGMA quick_check').get().quick_check !== 'ok') throw Error('Backup inconsistente.');
    } finally {check.close();}
    return {folder, dest};
  } catch (err) {
    await fs.rm(folder, {recursive: true, force: true});
    throw err;
  } finally {db.close();}
}
if (require.main === module) createBackup().then(r => console.log('Backup criado: ' + r.dest)).catch(err => {console.error(err.message); process.exitCode = 1;});
module.exports = {createBackup};
