'use strict';
window.SupremaUI={
 esc:v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),
 modal({title,body,button='Salvar',onSubmit}){
  const dialog=document.createElement('dialog');dialog.className='suprema-dialog';dialog.setAttribute('aria-label',title);
  const esc=window.SupremaUI.esc;
  dialog.innerHTML=`<form class="dialog-form"><div class="dialog-heading"><h2>${esc(title)}</h2><button type="button" class="dialog-close" aria-label="Fechar">\u00d7</button></div><div class="dialog-body">${body}</div><p class="form-error" role="alert" hidden></p><div class="dialog-actions"><button type="button" class="btn cancel">Cancelar</button><button type="submit" class="btn primary">${esc(button)}</button></div></form>`;
  document.body.append(dialog);
  dialog.querySelector('.dialog-close').onclick=()=>dialog.close();dialog.querySelector('.cancel').onclick=()=>dialog.close();
  dialog.addEventListener('close',()=>dialog.remove(),{once:true});
  dialog.querySelector('form').onsubmit=async e=>{
   e.preventDefault();const submit=dialog.querySelector('[type=submit]'),error=dialog.querySelector('.form-error');submit.disabled=true;error.hidden=true;
   try{await onSubmit(Object.fromEntries(new FormData(e.target)),e.target);dialog.close();}catch(err){error.textContent=err.message;error.hidden=false;}finally{submit.disabled=false;}
  };
  dialog.showModal();return dialog;
 }
};
