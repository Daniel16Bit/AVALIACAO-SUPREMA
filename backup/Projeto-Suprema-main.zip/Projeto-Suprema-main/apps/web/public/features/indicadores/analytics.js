'use strict';
/* Patch 11.2: additive analysis only; never changes scores or publication. */
(function(){
 const byId=id=>document.getElementById(id);
 const exists=v=>v!==null&&v!==undefined&&v!==''&&Number.isFinite(Number(v));
 const escV=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const f=v=>exists(v)?Number(v).toLocaleString('pt-BR',{maximumFractionDigits:2}):'—';
 const make=(parent,id,title,subtitle)=>{
   let el=byId(id);if(!el){el=document.createElement('section');el.className='panel v112-panel';el.id=id;parent.appendChild(el)}
   el.innerHTML='<div class="panel-title"><div><h3>'+title+'</h3><p>'+subtitle+'</p></div></div><div class="v112-body" id="'+id+'-body"></div>';
   return byId(id+'-body');
 };
 function radar(points){
  if(points.length<3)return '<div class="empty-inline">São necessárias pelo menos três questões publicadas com valor máximo definido.</div>';
  const cx=205,cy=185,r=120,n=points.length;
  const at=(i,p)=>{const a=-Math.PI/2+2*Math.PI*i/n;return [cx+Math.cos(a)*r*p,cy+Math.sin(a)*r*p]};
  const poly=vals=>vals.map((p,i)=>at(i,p).map(v=>v.toFixed(1)).join(',')).join(' ');
  const rings=[.2,.4,.6,.8,1].map(q=>'<polygon points="'+poly(points.map(()=>q))+'" fill="none" stroke="'+(q===.6?'#ecab52':'#dbe3ed')+'" '+(q===.6?'stroke-dasharray="5 4"':'')+' stroke-width="'+(q===.6?'2':'1')+'"/>').join('');
  const axes=points.map((p,i)=>{const a=at(i,1),lab=at(i,1.22);return '<line x1="'+cx+'" y1="'+cy+'" x2="'+a[0]+'" y2="'+a[1]+'" stroke="#dbe3ed"/><text x="'+lab[0]+'" y="'+lab[1]+'" text-anchor="middle" font-size="11" fill="#304766">'+escV(p.short)+'</text>'}).join('');
  const plot=(field,color,fill)=>'<polygon points="'+poly(points.map(p=>Math.max(0,Math.min(1,p[field]??0))))+'" fill="'+fill+'" stroke="'+color+'" stroke-width="2.7"/>'+points.map((p,i)=>p[field]===null||p[field]===undefined?'':(()=>{const c=at(i,Math.max(0,Math.min(1,p[field])));return '<circle cx="'+c[0]+'" cy="'+c[1]+'" r="4" fill="'+color+'"><title>'+escV(p.short)+': '+(Number(p[field])*100).toFixed(1)+'%</title></circle>'})()).join('');
  const student=points.some(p=>p.studentPct!==null);
  return '<div class="v117-radar-layout"><svg role="img" aria-label="Gráfico em teia de aproveitamento por questão, com referência de 60 por cento" viewBox="0 0 410 380" class="v117-radar-svg">'+rings+axes+plot('classPct','#2563c5','rgba(37,99,197,.15)')+(student?plot('studentPct','#0e9f76','rgba(14,159,118,.12)'):'')+'<text x="'+(cx+13)+'" y="'+(cy-r*.6-6)+'" font-size="11" fill="#ae791c">60%</text></svg><div class="v117-radar-legend"><strong>Desempenho por questão</strong><span><i style="background:#2563c5"></i>Média da turma</span>'+(student?'<span><i style="background:#0e9f76"></i>Estudante selecionado</span>':'')+'<span><i style="background:#e4ae5b"></i>Referência: 60%</span><small>Escala de 0% a 100% do valor máximo de cada questão. Passe o mouse sobre os pontos para ver os percentuais.</small></div></div>';
 }

 function getPoints(s,student){return (s.questionStats||[]).filter(q=>q.used&&Number(q.max_value)>0).map((q,i)=>({short:q.field_key?.toUpperCase()||('Q'+(i+1)),classPct:Number(q.mean||0)/Number(q.max_value),studentPct:student&&exists(student[q.field_key])?Number(student[q.field_key])/Number(q.max_value):null}));}
 function renderExtras(){
   const root=byId('resultsTab'),s=typeof currentStats!=='undefined'?currentStats:null;
   if(!root||!s)return;
   const resultArea=make(root,'v112-quadrants','Classificação em quatro grupos','Comparação pela nota da prova, média da turma e ponto de corte fixo em 60% da pontuação máxima.');
   const max=Number(s.provaMax||0),rows=(s.rows||[]).filter(x=>exists(x.nota_prova));
   if(!(max>0)||!rows.length){resultArea.innerHTML='<div class="empty-inline">Sem notas da prova publicadas ou sem valor máximo definido para calcular os 60%.</div>'}
   else{
     const mean=rows.reduce((a,r)=>a+Number(r.nota_prova),0)/rows.length,cut=.6*max;
     const counts=[0,0,0,0];rows.forEach(r=>{const v=Number(r.nota_prova);counts[(v>=mean?0:2)+(v>=cut?0:1)]++});
     const labels=['Acima/igual à média · ≥ 60%','Acima/igual à média · < 60%','Abaixo da média · ≥ 60%','Abaixo da média · < 60%'];
     resultArea.innerHTML='<div class="v112-grid">'+counts.map((v,i)=>'<div class="v112-quadrant v112-q'+i+'"><span>'+escV(labels[i])+'</span><strong>'+v+'</strong><small>'+Math.round(v/rows.length*100)+'% dos alunos com nota</small></div>').join('')+'</div><p class="v112-note">Média da prova: '+f(mean)+' · Corte de 60%: '+f(cut)+' de '+f(max)+' · A igualdade com a média pertence ao grupo “acima/igual”. Classificação apenas analítica.</p>';
   }
   const rbody=make(root,'v112-radar-class','Gráfico em teia — turma','Aproveitamento médio por questão, usando apenas questões publicadas com valor máximo.');
   rbody.innerHTML=radar(getPoints(s,null));
   let host=byId('v112-history');
   if(!host){host=document.createElement('section');host.id='v112-history';host.className='v113-history-control';root.append(host)}
   host.innerHTML='<button type="button" class="btn v113-history-btn">◷ Histórico de operações</button>';
   const aid=currentAssessment?.id;
   host.querySelector('button').onclick=()=>{
     if(!aid)return;
     const overlay=document.createElement('div');overlay.className='v113-history-overlay';overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-label','Histórico de operações');
     overlay.innerHTML='<section class="v113-history-dialog"><div class="v113-history-top"><div><h3>Histórico de operações</h3><p>Salvamentos, publicações e configurações; não registra versões anteriores de cada célula.</p></div><button type="button" class="btn v113-history-close">Fechar</button></div><div class="v113-history-content">Carregando...</div></section>';
     const close=()=>{overlay.remove();document.removeEventListener('keydown',onKey)};
     const onKey=e=>{if(e.key==='Escape')close()};
     overlay.querySelector('button').onclick=close;overlay.addEventListener('click',e=>{if(e.target===overlay)close()});document.addEventListener('keydown',onKey);document.body.appendChild(overlay);overlay.querySelector('button').focus();
     fetch('/api/assessment/'+encodeURIComponent(aid)+'/audit-history',{credentials:'same-origin'}).then(r=>{if(!r.ok)throw Error();return r.json()}).then(d=>{
       if(!overlay.isConnected)return;
       overlay.querySelector('.v113-history-content').innerHTML=d.length?'<div class="v112-history-list">'+d.map(e=>'<div><time>'+escV(e.created_at)+'</time><strong>'+escV(({'SALVAR_RASCUNHO':'Rascunho salvo','PUBLICAR_NOTAS':'Resultados publicados','ENCERRAR_AVALIACAO':'Edição encerrada','CONFIGURAR_QUESTAO':'Configuração de questão alterada','ALTERAR_CABECALHOS':'Cabeçalhos alterados'})[e.action]||e.action)+'</strong><span>'+escV(e.actor_name||'Usuário não identificado')+'</span></div>').join('')+'</div>':'Nenhuma operação registrada.';
     }).catch(()=>{if(overlay.isConnected)overlay.querySelector('.v113-history-content').textContent='Histórico indisponível.'});
   };

 }
 function renderStudentRadar(){
  const root=byId('individualTab'),s=typeof currentStats!=='undefined'?currentStats:null;
  if(!root||!s)return;
  const rows=s.rows||[],id=byId('studentSelect')?.value,student=rows.find(r=>String(r.id)===String(id));
  const body=make(root,'v112-radar-individual','Gráfico em teia — estudante x turma','Comparação percentual do aproveitamento por questão publicada.');
  body.innerHTML=student?radar(getPoints(s,student)):'<div class="empty-inline">Selecione um estudante com resultado publicado.</div>';
 }
 const oldStats=renderStats;renderStats=function(){oldStats.apply(this,arguments);renderExtras()};
 const oldIndividual=renderIndividual;renderIndividual=function(){oldIndividual.apply(this,arguments);renderStudentRadar()};
})();
