'use strict';
const crypto=require('node:crypto');
const {fail,audit}=require('./domain');
function validatePassword(password){if(typeof password!=='string'||password.length<8||password.length>128)fail(400,'Use uma senha entre 8 e 128 caracteres.');}
function hashPassword(password){validatePassword(password);const salt=crypto.randomBytes(16).toString('hex');return salt+':'+crypto.scryptSync(password,salt,64).toString('hex');}
function hashPasswordAsync(password){validatePassword(password);const salt=crypto.randomBytes(16).toString('hex');return new Promise((resolve,reject)=>crypto.scrypt(password,salt,64,(err,key)=>err?reject(err):resolve(salt+':'+key.toString('hex'))));}
function verifyPassword(password,stored){
 try{if(typeof password!=='string'||password.length>128)return false;const [salt,hash]=String(stored||'').split(':');if(!/^[a-f0-9]{32}$/i.test(salt)||!/^[a-f0-9]{128}$/i.test(hash))return false;return crypto.timingSafeEqual(Buffer.from(hash,'hex'),crypto.scryptSync(password,salt,64));}catch{return false;}
}
function installSecurity(app,db,{secureCookie=false}={}){
 const sessions=new Map(),attempts=new Map();const TTL=8*60*60*1000;
 const tokenOf=req=>(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('as_session='))?.slice(11);
 const cookie=(token,age)=>`as_session=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${age}${secureCookie?'; Secure':''}`;
 const publicUser=u=>({id:u.id,name:u.name,role:u.role,studentId:u.student_id||null});
 const auth=(req,res,next)=>{
  const token=tokenOf(req),s=sessions.get(token);
  if(!s||s.expires<Date.now()){if(token)sessions.delete(token);return res.status(401).json({error:'Sess\u00e3o expirada. Entre novamente.'});}
  const u=db.prepare('SELECT id,name,role,student_id,active,session_version FROM users WHERE id=?').get(s.id);
  if(!u||!u.active||u.role!==s.role||u.session_version!==s.version){sessions.delete(token);return res.status(401).json({error:'Sess\u00e3o encerrada. Entre novamente.'});}
  req.user=publicUser(u);next();
 };
 const role=expected=>(req,res,next)=>req.user.role===expected?next():res.status(403).json({error:'Seu perfil n\u00e3o tem permiss\u00e3o para esta opera\u00e7\u00e3o.'});
 const cleanup=setInterval(()=>{const now=Date.now();for(const [k,v] of sessions)if(v.expires<now)sessions.delete(k);for(const [k,v]of attempts)if(v.until<now)attempts.delete(k);},60000);cleanup.unref();
 app.post('/api/login',(req,res)=>{
  const login=String(req.body?.login||'').trim().toLowerCase().slice(0,240),password=req.body?.password;
  const key=req.socket.remoteAddress+'|'+login,ipKey='ip|'+req.socket.remoteAddress;
  for(const [k,limit] of [[key,6],[ipKey,80]]){const a=attempts.get(k);if(a&&a.until>Date.now()&&a.count>=limit){res.setHeader('Retry-After',String(Math.ceil((a.until-Date.now())/1000)));return res.status(429).json({error:'Muitas tentativas. Aguarde alguns minutos e tente novamente.'});}}
  const u=login?db.prepare('SELECT * FROM users WHERE lower(email)=? OR lower(matricula)=?').get(login,login):null;
  if(!u||!u.active||!['ADMIN','PROFESSOR','ALUNO'].includes(u.role)||!verifyPassword(password,u.password_hash)){
   for(const k of [key,ipKey]){const a=attempts.get(k);attempts.set(k,{count:a&&a.until>Date.now()?a.count+1:1,until:a&&a.until>Date.now()?a.until:Date.now()+5*60000});}
   return res.status(401).json({error:'Acesso n\u00e3o autorizado. Confira usu\u00e1rio, senha ou situa\u00e7\u00e3o do cadastro com o administrador.'});
  }
  attempts.delete(key);const old=tokenOf(req);if(old)sessions.delete(old);
  const token=crypto.randomBytes(32).toString('hex');sessions.set(token,{id:u.id,role:u.role,version:u.session_version,expires:Date.now()+TTL});
  db.prepare('UPDATE users SET invalid_attempts=0 WHERE id=?').run(u.id);
  audit(db,u,'LOGIN',{role:u.role});res.setHeader('Set-Cookie',cookie(token,TTL/1000));res.json({ok:true,user:publicUser(u)});
 });
 app.post('/api/logout',(req,res)=>{sessions.delete(tokenOf(req));res.setHeader('Set-Cookie',cookie('',0));res.json({ok:true});});
 app.get('/api/me',auth,(req,res)=>res.json(req.user));
 const clearLoginAttempts=logins=>{for(const k of [...attempts.keys()])if(logins.some(login=>k.endsWith('|'+String(login).toLowerCase())))attempts.delete(k);};
 const revokeUserSessions=uid=>{for(const [token,session] of sessions)if(session.id===uid)sessions.delete(token);};
 return {auth,role,revokeUserSessions,clearLoginAttempts,close:()=>clearInterval(cleanup)};
}
module.exports={hashPassword,hashPasswordAsync,validatePassword,verifyPassword,installSecurity};
